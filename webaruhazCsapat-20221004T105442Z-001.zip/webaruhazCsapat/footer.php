<div class="mt-5 p-4 bg-warning text-dark text-center" >
  <div class="row">
    <div class="col-md-2" id="rend">
      <p>Készitette:</p>
    </div>
    <div class="col-md-7" id="rend2"><p> Dimény Soma (Ambrus Kristóf, Kelemen Ádám, Lengyel Bálint)</p> </div>
      
    <div class="col-md-3" id="rend3"> <p>2022.10.04</p> </div> 
  </div>