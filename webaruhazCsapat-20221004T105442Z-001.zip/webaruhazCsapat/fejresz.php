<div class="p-5 bg-warning text-dark text-center fejresz">
  <h1>Dimény Soma webáruháza</h1>
  <p>Ambrus Kristóf, Kelemen Ádám, Lengyel Bálint, Dimény Soma</p> 
</div>